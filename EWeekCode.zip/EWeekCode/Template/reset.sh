#!/bin/bash

cp -y Control.py Model.py /home/robot/EWeekCode/